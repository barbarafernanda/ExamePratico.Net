import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component } from '@angular/core';
import { MediaResponse } from '../../core/models/relatorio.model';
import { RelatorioService } from '../../core/services/relatorio.service';

@Component({
  selector: 'app-relatorio',
  imports: [CommonModule],
  standalone: true,
  templateUrl: './relatorio.component.html',
  styleUrl: './relatorio.component.css'
})
export class RelatorioComponent {
  mediaAritmetica: number | null = null;
  loading = false;
  error: string | null = null;

  constructor(private relatorioService: RelatorioService,  private cdr: ChangeDetectorRef) {}

  gerarMedia() {
    debugger
    this.loading = true;
    this.error = null;
    this.relatorioService.gerarMedia().subscribe({
      next: (response: MediaResponse) => {
        debugger
        console.log(response.media);
        this.mediaAritmetica = response.media;
        this.loading = false;
        this.cdr.detectChanges();
      },
      error: (ex) => {
        console.log(ex);
        this.error = 'Erro ao carregar a média.';
        this.loading = false;
        this.cdr.detectChanges();
      }
    });
  }
}