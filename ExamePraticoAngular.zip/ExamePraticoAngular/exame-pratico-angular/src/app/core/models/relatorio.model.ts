export interface MediaResponse {
    media: number;
  }