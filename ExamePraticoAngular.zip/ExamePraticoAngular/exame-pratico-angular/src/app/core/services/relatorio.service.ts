import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MediaResponse } from '../models/relatorio.model';

@Injectable({
  providedIn: 'root'  
})
export class RelatorioService {
  private apiUrl = 'https://localhost:7189/VehicleInsurance/';

  constructor(private http: HttpClient) {}

  gerarMedia(): Observable<MediaResponse> {
    return this.http.get<MediaResponse>(this.apiUrl + "Gerar");;
  }
}